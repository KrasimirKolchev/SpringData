package dbAppsIntroduction.multipleImplementation;

public interface Birthable {

    String getBirthDate();
}
