package dbAppsIntroduction.mankind;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] inputS = reader.readLine().split("\\s+");

        String[] inputW = reader.readLine().split("\\s+");

        try {
            Student student = new Student(inputS[0], inputS[1], inputS[2]);
            Worker worker = new Worker(inputW[0], inputW[1], Double.parseDouble(inputW[2]), Integer.parseInt(inputW[3]));

            System.out.println(student.toString() + System.lineSeparator());
            System.out.println(worker.toString());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
