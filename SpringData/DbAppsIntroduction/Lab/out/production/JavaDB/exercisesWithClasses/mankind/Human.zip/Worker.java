package dbAppsIntroduction.mankind;

public class Worker extends Human {
    private double salary;
    private double workingHours;

    public Worker(String firstName, String lastName, double salary, double workingHours) {
        super(firstName, lastName);
        this.setSalary(salary);
        this.setWorkingHours(workingHours);
    }

    public double getSalary() {
        return this.salary;
    }

    public void setSalary(double salary) {
        if (salary <= 10) {
            throw new IllegalArgumentException("Expected value mismatch!Argument: weekSalary");
        }
        this.salary = salary;
    }

    public double getWorkingHours() {
        return this.workingHours;
    }

    public void setWorkingHours(double workingHours) {
        if (workingHours < 1 || workingHours > 12) {
            throw new IllegalArgumentException("Expected value mismatch!Argument: workHoursPerDay");
        }
        this.workingHours = workingHours;
    }

    @Override
    public void setLastName(String lastName) {
        if (!Character.isUpperCase(lastName.charAt(0))) {
            throw new IllegalArgumentException("Expected upper case letter!Argument: lastName");
        }
        if (lastName.length() < 3) {
            throw new IllegalArgumentException("Expected length more than 3 symbols!Argument: lastName");
        }

        super.setLastName(lastName);
    }

    public double getSalaryPerHour() {
        return ((this.getSalary() / 7) / this.getWorkingHours());
    }

    @Override
    public String toString() {
        return String.format("%sWeek Salary: %.2f\nHours per day: %.2f\nSalary Per hour: %.2f"
                       , super.toString(), getSalary(), getWorkingHours(), getSalaryPerHour());
    }
}
