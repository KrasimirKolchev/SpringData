package dbAppsIntroduction.Telephony;

public interface Browsable {
    String browse();
}
