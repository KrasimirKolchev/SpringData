package dbAppsIntroduction.Telephony;

public interface Callable {
    String call();
}
