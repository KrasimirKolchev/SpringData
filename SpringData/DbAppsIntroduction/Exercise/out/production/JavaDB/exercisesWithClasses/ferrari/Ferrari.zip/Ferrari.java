package dbAppsIntroduction.ferrari;

public class Ferrari implements Car{
    private String model;
    private String driver;

    public Ferrari(String driver) {
        this.driver = driver;
        this.model = "488-Spider";
    }

    public String getModel() {
        return model;
    }

    public String getDriver() {
        return driver;
    }

    @Override
    public String brakes() {
        return "Brakes!";
    }

    @Override
    public String gasPedal() {
        return "Zadu6avam sA!";
    }

    @Override
    public String toString() {
        return String.format("%s/%s/%s/%s", this.getModel(), this.brakes(), this.gasPedal(), this.getDriver());
    }
}
