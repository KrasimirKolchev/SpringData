package dbAppsIntroduction.ferrari;

public interface Car {

    String brakes();

    String gasPedal();
}
