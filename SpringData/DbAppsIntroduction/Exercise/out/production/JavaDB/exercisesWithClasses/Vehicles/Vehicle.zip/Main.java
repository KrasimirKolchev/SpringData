package dbAppsIntroduction.Vehicles;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] carData = reader.readLine().split("\\s+");
        Vehicle car = new Car(Double.parseDouble(carData[1]), Double.parseDouble(carData[2]));

        String[] truckData = reader.readLine().split("\\s+");
        Vehicle truck = new Truck(Double.parseDouble(truckData[1]), Double.parseDouble(truckData[2]));

        int lines = Integer.parseInt(reader.readLine());

        for (int i = 0; i < lines; i++) {
            String[] command = reader.readLine().split("\\s+");

            switch (command[0]) {
                case "Drive":
                    try {
                        switch (command[1]) {
                            case "Car":
                                car.drive(Double.parseDouble(command[2]));
                                break;
                            case "Truck":
                                truck.drive(Double.parseDouble(command[2]));
                                break;
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "Refuel":
                    switch (command[1]) {
                        case "Car":
                            car.refuel(Double.parseDouble(command[2]));
                            break;
                        case "Truck":
                            truck.refuel(Double.parseDouble(command[2]));
                            break;
                    }
                    break;
            }
        }

        System.out.printf("%s\n%s", car.toString(), truck.toString());
    }
}
