package dbAppsIntroduction.Vehicles;

import java.text.DecimalFormat;

public class Car extends Vehicle {
    private static final double AIR_COND_CONS = 0.9;

    public Car(double fuelQuantity, double litersPerKm) {
        super(fuelQuantity, litersPerKm);
    }

    @Override
    public void drive(double distance) {
        if ((this.getLitersPerKm() + AIR_COND_CONS) * distance <= this.getFuelQuantity()) {
            this.setDistance(this.getDistance() + distance);
            this.setFuelQuantity(this.getFuelQuantity() - ((this.getLitersPerKm() + AIR_COND_CONS) * distance));
        } else {
            throw new IllegalArgumentException("Car needs refueling");
        }
        DecimalFormat df = new DecimalFormat("#.######");
        System.out.println(String.format("Car travelled %s km", df.format(distance)));
    }

    @Override
    public void refuel(double liters) {
        this.setFuelQuantity(this.getFuelQuantity() + liters);
    }
}
