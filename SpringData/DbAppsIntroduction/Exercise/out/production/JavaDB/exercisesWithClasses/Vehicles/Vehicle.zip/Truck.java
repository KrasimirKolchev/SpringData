package dbAppsIntroduction.Vehicles;

import java.text.DecimalFormat;

public class Truck extends Vehicle {
    private static final double AIR_COND_CONS = 1.6;
    private static final double FUEL_LOSS = 0.95;

    public Truck(double fuelQuantity, double litersPerKm) {
        super(fuelQuantity, litersPerKm);
    }

    @Override
    public void drive(double distance) {
        if ((this.getLitersPerKm() + AIR_COND_CONS) * distance <= this.getFuelQuantity()) {
            this.setDistance(this.getDistance() + distance);
            this.setFuelQuantity(this.getFuelQuantity() - (this.getLitersPerKm() + AIR_COND_CONS) * distance);
        } else {
            throw new IllegalArgumentException("Truck needs refueling");
        }

        DecimalFormat df = new DecimalFormat("#.##################");
        System.out.println(String.format("Truck travelled %s km", df.format(distance)));
    }

    @Override
    public void refuel(double liters) {
        this.setFuelQuantity(this.getFuelQuantity() + (liters * FUEL_LOSS));
    }
}
