package dbAppsIntroduction.animals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String command;
        while (!"Beast!".equals(command = reader.readLine())) {
            String[] data = reader.readLine().split("\\s+");
            Animal animal = null;
            try {
                switch (command) {
                    case "Cat" :
                        animal = new Cat(data[0], Integer.parseInt(data[1]), data[2]);
                        break;
                    case "Dog" :
                        animal = new Dog(data[0], Integer.parseInt(data[1]), data[2]);
                        break;
                    case "Kitten" :
                        animal = new Kitten(data[0], Integer.parseInt(data[1]));
                        break;
                    case "Tomcat" :
                        animal = new Tomcat(data[0], Integer.parseInt(data[1]));
                        break;
                    case "Frog" :
                        animal = new Frog(data[0], Integer.parseInt(data[1]), data[2]);
                        break;
                    case "Animal" :
                        System.out.println("Not implemented!");
                        break;
                }
                if (animal != null) {
                    System.out.println(animal.toString());
                }

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
