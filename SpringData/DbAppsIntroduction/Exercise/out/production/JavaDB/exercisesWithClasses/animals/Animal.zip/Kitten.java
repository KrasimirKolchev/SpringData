package dbAppsIntroduction.animals;

public class Kitten extends Cat {
    private static final String KITTEN_GENDER = "Female";

    public Kitten(String name, int age) throws Exception {
        super(name, age, KITTEN_GENDER);
    }

    @Override
    public String produceSound() {
        return "Miau";
    }
}
